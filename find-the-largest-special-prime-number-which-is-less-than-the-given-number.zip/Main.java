import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
            int n = ps.nextInt(),temp=0,s=1;
            int k = n;
            for(int i = 1;i<=n;i++){
                if(n%i==0){
                    temp++;
                    s=0;
                }
            }
            if(temp==2){
                System.out.print(n);
            }
            if(s==0)
            for(int i = n;i>=0;i--){
                temp=0;
                for(int j = 1;j<=k;j++){
                    if(i%j==0){
                        temp++;
                    }
                }
                if(temp==2){
                    System.out.println(i);
                break;}
            }
        }
    }
